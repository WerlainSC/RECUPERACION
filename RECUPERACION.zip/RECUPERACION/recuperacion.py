import ply.lex as lex
import ply.yacc as yacc
from flask import Flask, request, render_template

# Inicializar la aplicación Flask
app = Flask(__name__)

# Definir tokens para el analizador léxico
tokens = (
    'DELIMITADOR',
    'VARIABLE',
    'ASIGNACION',
    'TEXTO',
    'NUMERO',
    'CADENA',
    'IDENTIFICADOR',  # Agrega el token de identificador aquí
)

# Expresiones regulares para tokens simples
t_DELIMITADOR = r'[<>/]'
t_VARIABLE = r'html|head|title|body'
t_ASIGNACION = r'\w+="[^"]*"'
t_TEXTO = r'[^<>]+'
t_NUMERO = r'\d+'
t_CADENA = r'Mi primer Web|Hola Mundo'

# Ignorar espacios y tabs
t_ignore = ' \t'

# Variable global para mensaje de error
error_message = ""

# Manejar errores léxicos
def t_error(t):
    global error_message
    print(f"Error léxico: No se reconoce el token '{t.value[0]}'")
    t.lexer.skip(1)
    error_message = "Error léxico"

# Construir el analizador léxico
lexer = lex.lex()

# Reglas de gramática para el analizador sintáctico
def p_texto(p):
    '''texto : TEXTO'''
    p[0] = "Resultado Correcto" if check_required_lines(p[1]) else "Error de estructura"

def check_required_lines(texto):
    required_lines = [
        '<!DOCTYPE html>',
        '<HTML>',
        '     <head>',
        '\t<title> Mi primer Web</title>',
        '    </head>',
        '    <body>',
        '<h1> Hola Mundo!</h1>',
        '</body>',
        '</html>',
    ]
    for line in required_lines:
        if line not in texto:
            return False
    return True

# Manejar errores sintácticos
def p_error(p):
    global error_message
    print("Error sintáctico")
    error_message = "Error sintáctico"

# Construir el analizador sintáctico
parser = yacc.yacc()

# Ruta principal
@app.route('/', methods=['GET', 'POST'])
def index():
    global error_message
    if request.method == 'POST':
        texto = request.form['texto']
        resultado = parser.parse(texto)
        return render_template('resultado.html', resultado=resultado, error_message=error_message)
    return render_template('formulario.html')

if __name__ == '__main__':
    app.run(debug=True)
